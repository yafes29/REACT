import "../../scss/_header.scss";
import Navbar from "../navbar/Navbar";

const Header = () => {
  return (

    <header>

      <Navbar />

    </header>





  )
}

export default Header